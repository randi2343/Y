📦 Randi Bot - WhatsApp Catalog Case Bot

Cara install:
1. Ekstrak ZIP ini
2. Buka terminal di folder hasil ekstrak
3. Jalankan:
   npm install
4. Jalankan bot:
   npm start

Pastikan kamu sudah login WhatsApp saat QR Code muncul.
