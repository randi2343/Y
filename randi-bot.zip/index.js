const { Client, LocalAuth, MessageMedia } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');

const client = new Client({
    authStrategy: new LocalAuth()
});

client.on('qr', qr => {
    qrcode.generate(qr, { small: true });
});

client.on('ready', () => {
    console.log('🤖 Bot Randi siap digunakan!');
});

client.on('message', async message => {
    const text = message.body.toLowerCase();

    if (text === 'menu') {
        client.sendMessage(message.from, `📱 *Selamat Datang di Randi Case Store!* 💼

Berikut katalog case HP terbaru:

1️⃣ iPhone 🍎
2️⃣ Samsung 📲
3️⃣ Xiaomi 📶
4️⃣ Oppo/Vivo 🌟
5️⃣ Realme 🎧

🛒 Ketik angka atau nama merk untuk melihat case-nya.
📦 Ketik *order* untuk memesan.
📞 Ketik *kontak* untuk info admin.`);
    }

    if (text.includes('iphone')) {
        client.sendMessage(message.from, `🍎 *Case iPhone Terbaru:*

• iPhone 13 Soft Matte Case
• iPhone 13 Pro Max Armor Shockproof
• iPhone 14 Clear MagSafe
• iPhone 15 Pro Max Carbon Edition

Ketik *order + nama produk* untuk pesan.`);
    }

    if (text === 'kontak') {
        const vCard = 'BEGIN:VCARD\n' +
            'VERSION:3.0\n' +
            'FN:Randi Admin\n' +
            'ORG:Randi Case Store;\n' +
            'TEL;type=CELL;type=VOICE;waid=6283867759076:+62 838-6775-9076\n' +
            'END:VCARD';

        const contact = new MessageMedia('text/vcard', Buffer.from(vCard).toString('base64'), 'contact.vcf');
        client.sendMessage(message.from, contact, { caption: '📞 Hubungi Admin Randi' });
    }
});

client.initialize();
